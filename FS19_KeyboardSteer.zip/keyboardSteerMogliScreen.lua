--***************************************************************
--
-- keyboardSteerMogliScreen
-- 
-- version 2.200 by mogli (biedens)
--
--***************************************************************

--***************************************************************
source(Utils.getFilename("mogliScreen.lua", g_currentModDirectory))
_G[g_currentModName..".mogliScreen"].newClass( "keyboardSteerMogliScreen", "keyboardSteerMogli", "ksm", "ksmUI" )
--***************************************************************

